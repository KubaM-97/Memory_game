<?php 
echo '
<div id="page_lose">
    <div class="video"></div>

    <div class="content" style="display: none;">

        <div class="statistics_lose">Game Over! You die!</div>

        <div class="buttons buttons_end_lose">
            <button class="button main_menu">Main menu</button>
            <button class="button try_again">Try again</button>
        </div>

    </div>
</div>
'
?>