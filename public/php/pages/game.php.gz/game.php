
<?php 
echo '  
    <div id="page_play">
        <div id="game_cards"></div>
        <div id="timer">Time: <br> <span id="timeCounter"></span></div>
        <div id="score">Moves: <br> <span id="scoreCounter">0</span></div>
    </div> 
'
?>